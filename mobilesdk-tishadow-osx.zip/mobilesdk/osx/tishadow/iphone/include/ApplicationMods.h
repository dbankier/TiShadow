/**
 * Appcelerator Titanium Mobile
 * This is generated code. Do not modify. Your changes will be lost.
 */
#import <Foundation/Foundation.h>

@interface ApplicationMods : NSObject {

}
+ (NSArray*) compiledMods;
@end
