/**
 * This is a generated file. Do not edit or your changes will be lost
 */

@interface ___PROJECTNAMEASIDENTIFIER___ModuleAssets : NSObject
{
}
- (NSData*) moduleAsset;
@end
