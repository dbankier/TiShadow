#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Titanium Compiler plugin 
# __PROJECT_ID__
#


def compile(config):
	print "[INFO] __PROJECT_ID__ plugin loaded"
	
